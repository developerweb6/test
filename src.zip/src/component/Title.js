import React from 'react'

function Title() {
  return (
    <header>
     <h1>SFPOPOS</h1>
    </header>
     
    
  )
}

export default Title