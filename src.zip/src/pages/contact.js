import React from 'react';
  
const Events = () => {
  return (
    <div className="body-layout">
      <h1>Welcome to GeeksforGeeks Events</h1>
    </div>
  );
};
  
export default Events;