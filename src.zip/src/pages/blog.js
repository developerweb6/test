import React from 'react';
  
const Blogs = () => {
  return (
    <div className="body-layout">
      <h1>Welcome to GeeksforGeeks Blogs</h1>
    </div>
  );
};
  
export default Blogs;